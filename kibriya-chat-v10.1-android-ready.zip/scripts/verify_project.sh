#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "== Kibriya Chat environment check =="
command -v node >/dev/null && node --version || echo "WARN: Node.js غير موجود"
command -v npm >/dev/null && npm --version || echo "WARN: npm غير موجود"
if command -v flutter >/dev/null; then flutter --version | head -1; else echo "WARN: Flutter غير مثبت — لا يمكن تشغيل flutter analyze/build هنا."; fi

node --check server/src/server.js
node --check server/src/zegoToken.js

for f in server/sql/*.sql; do
  grep -q "^--\|CREATE\|ALTER\|INSERT\|UPDATE\|DO" "$f" || { echo "WARN: ملف SQL غير معتاد: $f"; }
done

required=(app/pubspec.yaml app/lib/main.dart app/lib/core/config.dart server/package.json server/src/server.js server/sql/010_cosmetics_stickers.sql)
for f in "${required[@]}"; do
  test -f "$f" || { echo "MISSING: $f"; exit 1; }
done

echo "Node syntax: OK"
echo "Core files: OK"
echo "Assets: $(find app/assets -type f | wc -l) files"
echo "Environment is prepared; Flutter build requires Flutter SDK."
