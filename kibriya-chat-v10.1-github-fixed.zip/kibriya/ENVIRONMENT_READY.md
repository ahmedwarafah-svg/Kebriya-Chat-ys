# تم تجهيز بيئة مشروع كبرياء شات V10.1

تمت إضافة:
- تعليمات Toolchain كاملة.
- سكربت توليد منصات Android/iOS عند توفر Flutter.
- سكربت إنشاء `.env` تطويري بدون أسرار حقيقية.
- فحص تلقائي للكود وملفات المشروع.
- إعداد VS Code tasks.
- إعداد Dart/Flutter lint.
- أوامر npm للتطوير والفحص.
- Makefile لأوامر التجهيز والتشغيل.
- ملف `.gitignore` يمنع تسريب الأسرار وملفات build/uploads.
- قالب بيئة تطوير منفصل للـBackend.

## ملاحظة
البيئة الحالية التي تم تجهيز الحزمة منها تحتوي Node.js وJava، لكن لا تحتوي Flutter SDK؛ لذلك لم يتم الادعاء ببناء APK. بعد تثبيت Flutter 3.29+ شغّل:

```bash
./scripts/bootstrap_flutter_platforms.sh
./scripts/verify_project.sh
```

ثم اربط PostgreSQL وRedis وشغّل الـBackend.
