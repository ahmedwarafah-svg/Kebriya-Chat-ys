class AppConfig {
  static const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:8080');
  static const zegoAppId = int.fromEnvironment('ZEGO_APP_ID', defaultValue: 0);
  static const zegoAppSign = String.fromEnvironment('ZEGO_APP_SIGN', defaultValue: '');
  static const brand = 'كبرياء شات';
  static const subtitle = 'حفلات ودردشة صوتية';
}
