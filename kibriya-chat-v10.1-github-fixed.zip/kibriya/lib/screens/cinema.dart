import 'package:flutter/material.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

class CinemaScreen extends StatefulWidget{final String roomId;const CinemaScreen({super.key,required this.roomId});@override State<CinemaScreen> createState()=>_CinemaState();}
class _CinemaState extends State<CinemaScreen>{late YoutubePlayerController controller;final url=TextEditingController();bool cinema=false;@override void initState(){super.initState();controller=YoutubePlayerController();}
void _load(){final id=YoutubePlayerController.convertUrlToId(url.text.trim());if(id!=null){controller.loadVideoById(videoId:id);setState(()=>cinema=true);}}
@override void dispose(){controller.close();url.dispose();super.dispose();}
@override Widget build(BuildContext c)=>Scaffold(backgroundColor:Colors.black,appBar:AppBar(title:const Text('🎬 سينما الغرفة'),actions:[IconButton(onPressed:()=>setState(()=>cinema=!cinema),icon:Icon(cinema?Icons.fullscreen_exit:Icons.fullscreen))]),body:Column(children:[Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(controller:url,decoration:const InputDecoration(hintText:'ضع رابط YouTube للفيديو'))),const SizedBox(width:8),FilledButton(onPressed:_load,child:const Text('تشغيل'))])),Expanded(child:YoutubePlayer(controller:controller,aspectRatio:16/9)),Padding(padding:const EdgeInsets.all(12),child:Text('الغرفة $roomId • وضع السينما: ${cinema?'مفعّل':'جاهز'}',style:const TextStyle(color:Colors.white70))) ]));}
