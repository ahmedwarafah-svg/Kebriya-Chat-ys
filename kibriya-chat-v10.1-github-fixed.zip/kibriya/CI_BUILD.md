# GitHub Actions APK build

- Flutter: 3.29.3 by default
- Dart: supplied by Flutter 3.29.3
- Java: 17 (Temurin)
- Build: `flutter build apk --release`
- Artifact: `artifacts/kibriya-chat-<run>.apk`
- If `API_BASE_URL` is configured as a GitHub Repository Variable, it is embedded at build time.
- `ZEGO_APP_ID` is read from a Repository Variable and `ZEGO_APP_SIGN` from a Secret.
- The current Android release configuration uses the debug signing key, so the APK is installable for testing but is not a Play Store production-signed artifact.
