# كبرياء شات — Feature Matrix

## Core
- Arabic RTL-ready Flutter app
- Owner/Admin role
- REST API + Socket.IO
- PostgreSQL + Redis-ready infrastructure
- Persistent local image storage (`uploads` volume)
- 30-seat room layout

## Retention / Activities
- Daily presence streak (`نبض الحضور`)
- Daily task center
- Room visiting task
- Invite-a-friend task
- App-rating task
- Activity catalog seeded in database
- XP and level progression from daily presence

## Referral engine
- Unique referral code per user
- Shareable referral URL
- Click tracking
- Qualified signup attribution
- One-time invited-user relation
- Automatic coin reward per successful referral
- Referral earnings counter
- Anti-self-referral check through code ownership

## Rating
- 1–5 stars
- Optional comment
- One rating per user, editable
- Public average + count
- Rating task reward

## Storage
- Multipart image upload
- 8 MB limit
- JPEG/PNG/WebP/GIF validation
- Static serving under `/uploads`
- Persistent Docker volume
- Avatar picker wired to profile screen

## Owner Panel
- Total users
- Live rooms
- Open reports
- Rating count
- Total coins in circulation
- User list
- Ban/unban
- Reports list

## Production dependencies still external
- ZEGOCLOUD credentials for live voice
- Public HTTPS domain for remote links
- Google Play/App Store accounts for distribution
- Payment provider for paid coin recharge
- Optional S3/CDN for scalable media storage


## V4 Economy & Engagement
- VIP + SVIP + relationship/bond gift category
- Charge level, charm/attraction stats
- Gift catalog: basic, combo, luck, SVIP, CV
- Gift bag with persistent quantities
- Gift send transaction with coin debit and receiver diamond/attraction credit
- Luck gift metadata for multipliers
- CV events and progress/claim
- Owner economy dashboard and gift/CV catalog views
- Fixed gift panel concept + compact live counter can be layered over the room UI
