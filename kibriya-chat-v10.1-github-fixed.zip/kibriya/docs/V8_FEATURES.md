# V8 Feature Map

- Room animated emotes: normal + progressive VIP 1–15 + SVIP 1–12.
- Room crown: total Coins, gifts and attraction are accumulated from all gifts thrown in the room.
- Lucky Bag: server-side coin deduction, one claim per user, recipient limit.
- Rocket milestone: 3 rockets are broadcast after the room reaches the configured support target.
- PK challenge: room-vs-room challenge model with target and scores.
- Room controls: title, announcement, entry lock, seat lock, max 30 seats.
- Backgrounds: preset SVG library + phone upload endpoint.
- Music: phone audio picker/local playback. Room-wide broadcast requires audio mixing/publishing integration.
- Families: create/join, group text/image/voice message storage.
- Private chat: mutual-follow gate, text/image/voice messages.
- Login: username/password, phone OTP scaffold, Google ID-token endpoint.
- Media storage: local image/audio uploads; ready to swap to object storage/CDN.
- CP terminology: public-facing CV naming is migrated to CP.
