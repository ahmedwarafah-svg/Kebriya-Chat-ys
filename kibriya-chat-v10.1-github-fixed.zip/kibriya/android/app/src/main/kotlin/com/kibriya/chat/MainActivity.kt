package com.kibriya.chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
