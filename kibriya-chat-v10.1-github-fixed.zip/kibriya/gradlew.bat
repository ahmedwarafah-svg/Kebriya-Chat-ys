@echo off
echo Kibriya Chat is a Flutter project.
echo Use: flutter pub get ^&^& flutter build apk --release
call android\gradlew.bat %*
