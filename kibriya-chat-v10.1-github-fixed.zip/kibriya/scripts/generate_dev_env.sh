#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/server"
if [ -f .env ]; then
  echo "server/.env موجود بالفعل — لن يتم استبداله."
  exit 0
fi
JWT_SECRET="$(openssl rand -hex 32 2>/dev/null || echo 'dev-jwt-secret-change-me-32-bytes')"
OTP_PEPPER="$(openssl rand -hex 32 2>/dev/null || echo 'dev-otp-pepper-change-me-32-bytes')"
POSTGRES_PASSWORD="$(openssl rand -hex 16 2>/dev/null || echo 'dev-postgres-password')"
REDIS_PASSWORD="$(openssl rand -hex 16 2>/dev/null || echo 'dev-redis-password')"
cat > .env <<ENV
NODE_ENV=development
PORT=8080
POSTGRES_USER=kibriya
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
POSTGRES_DB=kibriya
REDIS_PASSWORD=$REDIS_PASSWORD
DATABASE_URL=postgres://kibriya:$POSTGRES_PASSWORD@127.0.0.1:5432/kibriya
JWT_SECRET=$JWT_SECRET
OTP_PEPPER=$OTP_PEPPER
OWNER_USER_ID=
CORS_ORIGIN=*
PUBLIC_BASE_URL=http://127.0.0.1:8080
UPLOAD_DIR=./uploads
INVITE_REWARD_COINS=500
STARTER_COINS=1000000
ZEGO_APP_ID=0
ZEGO_SERVER_SECRET=
ZEGO_TOKEN_TTL=3600
GOOGLE_WEB_CLIENT_ID=
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_OTP_TEMPLATE=login_otp
WHATSAPP_OTP_LANGUAGE=ar
WHATSAPP_GRAPH_VERSION=v23.0
DEV_OTP_MODE=true
DEV_OTP=123456
ENV
chmod 600 .env
echo "تم إنشاء server/.env للتطوير المحلي. لا تستخدمه للإنتاج."
