# Kibriya Chat V10 — Security Checklist

## Owner control
- Public registration can never create an admin/owner account.
- Production admin access requires both `is_admin=true` in PostgreSQL and an exact `OWNER_USER_ID` match.
- `OWNER_USER_ID` must be configured only in the server environment; never ship it as a client secret.

## Authentication
- JWT uses issuer/audience validation and a configurable expiry.
- Production requires a strong `JWT_SECRET` and `OTP_PEPPER`.
- Login, registration and OTP endpoints are rate-limited.
- WhatsApp OTPs are stored as HMAC hashes, expire after 5 minutes and have limited attempts.

## Rooms
- Room moderation checks ownership or moderator membership.
- Banned users cannot join room sockets.
- Gift senders and receivers must be room members.
- ZEGOCLOUD ServerSecret stays on the backend; production clients should request tokens from `/api/zego/token`.

## Files and deployment
- Uploaded media receives random filenames and signature validation.
- Production requires HTTPS `PUBLIC_BASE_URL` and explicit `CORS_ORIGIN`.
- Database/Redis should not be exposed publicly.
- Never commit `.env`, database passwords, WhatsApp tokens, ZEGOCLOUD ServerSecret, or Android signing keys.

## Owner deployment
1. Create the owner account normally.
2. Run `server/sql/PROVISION_OWNER_TEMPLATE.sql` as database owner to set `is_admin=true`.
3. Put the owner's UUID into `OWNER_USER_ID` on the server only.
4. Keep the Android signing keystore and passwords offline/secure.
5. Rotate all secrets if they were ever shared publicly.

This is a hardening baseline, not a guarantee of zero vulnerabilities. A production launch should still include dependency updates, backups, monitoring and an independent penetration test.
