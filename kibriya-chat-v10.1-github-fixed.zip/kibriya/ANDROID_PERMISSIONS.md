أضف إلى android/app/src/main/AndroidManifest.xml داخل manifest:

<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<uses-permission android:name="android.permission.BLUETOOTH_SCAN" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.INTERNET" />

واستخدم Android SDK/Gradle versions المتوافقة مع إصدار Flutter الذي ستبني به المشروع.
