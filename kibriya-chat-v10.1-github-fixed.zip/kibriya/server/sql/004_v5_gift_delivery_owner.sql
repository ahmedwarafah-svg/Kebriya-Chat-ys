-- Kibriya Chat V5: gift burst delivery, balance visibility, recipient selection, owner control center
ALTER TABLE gift_transactions ADD COLUMN IF NOT EXISTS lucky_multiplier NUMERIC(8,2) NOT NULL DEFAULT 1;
ALTER TABLE gift_transactions ADD COLUMN IF NOT EXISTS sender_coins_before BIGINT NOT NULL DEFAULT 0;
ALTER TABLE gift_transactions ADD COLUMN IF NOT EXISTS sender_coins_after BIGINT NOT NULL DEFAULT 0;
ALTER TABLE gift_transactions ADD COLUMN IF NOT EXISTS delivery_mode VARCHAR(24) NOT NULL DEFAULT 'burst';

ALTER TABLE gifts ADD COLUMN IF NOT EXISTS combo_max INT NOT NULL DEFAULT 1;
UPDATE gifts SET combo_max=100 WHERE category='combo' AND combo_max<100;
UPDATE gifts SET combo_max=100 WHERE name='زوم بوم';

CREATE INDEX IF NOT EXISTS idx_gift_transactions_sender_created ON gift_transactions(sender_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_gift_transactions_receiver_created ON gift_transactions(receiver_id,created_at DESC);

CREATE TABLE IF NOT EXISTS owner_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  target_type VARCHAR(50),
  target_id UUID,
  payload JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_owner_audit_created ON owner_audit_log(created_at DESC);

INSERT INTO owner_settings(key,value) VALUES
('gift_burst_max', '{"value":100}'::jsonb),
('gift_burst_animation_ms', '{"value":160}'::jsonb),
('gift_balance_warning', '{"enabled":true,"threshold":1000}'::jsonb),
('owner_dashboard_refresh_seconds', '{"value":10}'::jsonb)
ON CONFLICT(key) DO NOTHING;
