-- Kibriya Chat V9.1 security hardening
-- This migration contains database-side indexes/constraints only.
-- Production secrets and OWNER_USER_ID must be configured outside the database.

CREATE INDEX IF NOT EXISTS idx_whatsapp_otps_expires ON whatsapp_otps(expires_at);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
CREATE INDEX IF NOT EXISTS idx_room_bans_room_user ON room_bans(room_id,user_id);
CREATE INDEX IF NOT EXISTS idx_owner_audit_created ON owner_audit_log(created_at DESC);

-- Prevent negative economic balances at the database boundary.
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='users_coins_nonnegative') THEN
    ALTER TABLE users ADD CONSTRAINT users_coins_nonnegative CHECK (coins >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='users_diamonds_nonnegative') THEN
    ALTER TABLE users ADD CONSTRAINT users_diamonds_nonnegative CHECK (diamonds >= 0);
  END IF;
END $$;
