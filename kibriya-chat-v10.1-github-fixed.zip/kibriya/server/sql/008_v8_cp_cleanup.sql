-- V8 terminology cleanup: CP is the public name; legacy CV tables remain only for migration compatibility.
UPDATE gifts SET name=REPLACE(name,'CV','CP'), metadata=jsonb_set(COALESCE(metadata,'{}'::jsonb),'{label}','"CP"') WHERE name ILIKE '%CV%';
UPDATE cp_events SET title=REPLACE(title,'CV','CP'), rules=jsonb_set(COALESCE(rules,'{}'::jsonb),'{type}','"cp"') WHERE title ILIKE '%CV%';
UPDATE achievement_gifts SET achievement_title=REPLACE(achievement_title,'CV','CP') WHERE achievement_title ILIKE '%CV%';
