-- V8: animated emotes, room wealth/attraction, lucky bags, rockets, PK, music/backgrounds, families, follows and private media messaging.
CREATE TABLE IF NOT EXISTS emotes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, asset_url TEXT NOT NULL,
  min_vip INT NOT NULL DEFAULT 0, min_svip INT NOT NULL DEFAULT 0, enabled BOOLEAN NOT NULL DEFAULT TRUE, sort_order INT NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS room_emote_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), room_id UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, emote_id UUID NOT NULL REFERENCES emotes(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS room_stats (
  room_id UUID PRIMARY KEY REFERENCES rooms(id) ON DELETE CASCADE, total_coins BIGINT NOT NULL DEFAULT 0,
  total_gifts BIGINT NOT NULL DEFAULT 0, total_diamonds BIGINT NOT NULL DEFAULT 0, total_attraction BIGINT NOT NULL DEFAULT 0, updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS room_backgrounds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), room_id UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  url TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'preset', is_active BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS lucky_bags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), room_id UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES users(id), total_coins BIGINT NOT NULL, remaining_coins BIGINT NOT NULL,
  recipients_limit INT NOT NULL DEFAULT 10, claimed_count INT NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'open', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS lucky_bag_claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), bag_id UUID NOT NULL REFERENCES lucky_bags(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id), amount BIGINT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(bag_id,user_id)
);
CREATE TABLE IF NOT EXISTS room_rockets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), room_id UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  target_coins BIGINT NOT NULL, progress_coins BIGINT NOT NULL DEFAULT 0, rocket_count INT NOT NULL DEFAULT 3,
  triggered BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS pk_challenges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), room_a UUID NOT NULL REFERENCES rooms(id), room_b UUID NOT NULL REFERENCES rooms(id),
  target_coins BIGINT NOT NULL DEFAULT 100000, score_a BIGINT NOT NULL DEFAULT 0, score_b BIGINT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending', started_at TIMESTAMPTZ, ends_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS families (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL, owner_id UUID NOT NULL REFERENCES users(id), icon_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS family_members (
  family_id UUID NOT NULL REFERENCES families(id) ON DELETE CASCADE, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member', joined_at TIMESTAMPTZ NOT NULL DEFAULT now(), PRIMARY KEY(family_id,user_id)
);
-- Existing follows/messages tables are extended rather than replaced.
ALTER TABLE messages ADD COLUMN IF NOT EXISTS kind TEXT;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS media_url TEXT;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS duration_ms INT;
UPDATE messages SET kind=COALESCE(kind,message_type,'text') WHERE kind IS NULL;
ALTER TABLE messages ALTER COLUMN body DROP NOT NULL;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS created_at_legacy TIMESTAMPTZ;
CREATE TABLE IF NOT EXISTS family_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), family_id UUID NOT NULL REFERENCES families(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES users(id), kind TEXT NOT NULL DEFAULT 'text', body TEXT, media_url TEXT, duration_ms INT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS auth_identities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL, provider_subject TEXT NOT NULL, phone_e164 TEXT, UNIQUE(provider,provider_subject)
);
INSERT INTO emotes(code,name,asset_url,min_vip,min_svip,sort_order) VALUES
('heart','قلب متحرك','assets/emotes/heart.json',0,0,1),('fire','نار متحركة','assets/emotes/fire.json',1,0,2),
('crown','تاج ملكي','assets/emotes/crown.json',5,0,3),('star','نجمة VIP','assets/emotes/star.json',10,0,4),
('dragon','تنين SVIP','assets/emotes/dragon.json',0,3,5),('galaxy','مجرة SVIP','assets/emotes/galaxy.json',0,8,6),
('royal','مؤثر ملكي','assets/emotes/royal.json',0,12,7) ON CONFLICT(code) DO NOTHING;
-- Progressive VIP/SVIP emote inventory. Each level inherits all previous emotes.
INSERT INTO emotes(code,name,asset_url,min_vip,min_svip,sort_order) VALUES
('vip1','VIP 1 قلب','assets/emotes/vip1.json',1,0,10),('vip2','VIP 2 برق','assets/emotes/vip2.json',2,0,11),
('vip3','VIP 3 ورد','assets/emotes/vip3.json',3,0,12),('vip4','VIP 4 نار','assets/emotes/vip4.json',4,0,13),
('vip5','VIP 5 تاج','assets/emotes/vip5.json',5,0,14),('vip6','VIP 6 ماسة','assets/emotes/vip6.json',6,0,15),
('vip7','VIP 7 صاعقة','assets/emotes/vip7.json',7,0,16),('vip8','VIP 8 نجمة','assets/emotes/vip8.json',8,0,17),
('vip9','VIP 9 لؤلؤة','assets/emotes/vip9.json',9,0,18),('vip10','VIP 10 تنين','assets/emotes/vip10.json',10,0,19),
('vip11','VIP 11 شهاب','assets/emotes/vip11.json',11,0,20),('vip12','VIP 12 مجرة','assets/emotes/vip12.json',12,0,21),
('vip13','VIP 13 أسطورة','assets/emotes/vip13.json',13,0,22),('vip14','VIP 14 إمبراطور','assets/emotes/vip14.json',14,0,23),
('vip15','VIP 15 ملكي','assets/emotes/vip15.json',15,0,24),
('svip1','SVIP 1 هالة','assets/emotes/svip1.json',0,1,30),('svip2','SVIP 2 نجوم','assets/emotes/svip2.json',0,2,31),
('svip3','SVIP 3 تنين','assets/emotes/svip3.json',0,3,32),('svip4','SVIP 4 برق ملكي','assets/emotes/svip4.json',0,4,33),
('svip5','SVIP 5 مجرة','assets/emotes/svip5.json',0,5,34),('svip6','SVIP 6 Phoenix','assets/emotes/svip6.json',0,6,35),
('svip7','SVIP 7 شهاب','assets/emotes/svip7.json',0,7,36),('svip8','SVIP 8 كون','assets/emotes/svip8.json',0,8,37),
('svip9','SVIP 9 ملك النجوم','assets/emotes/svip9.json',0,9,38),('svip10','SVIP 10 أسطورة','assets/emotes/svip10.json',0,10,39),
('svip11','SVIP 11 عرش','assets/emotes/svip11.json',0,11,40),('svip12','SVIP 12 الإمبراطور','assets/emotes/svip12.json',0,12,41)
ON CONFLICT(code) DO NOTHING;
