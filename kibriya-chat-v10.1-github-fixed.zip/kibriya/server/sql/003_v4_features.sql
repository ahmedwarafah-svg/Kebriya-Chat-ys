-- Kibriya Chat V4: VIP/SVIP, charge levels, attraction, gift catalog, bags, CV events, owner controls
ALTER TABLE users ADD COLUMN IF NOT EXISTS svip_level INT NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS charge_level INT NOT NULL DEFAULT 1;
ALTER TABLE users ADD COLUMN IF NOT EXISTS attraction BIGINT NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS charm_level INT NOT NULL DEFAULT 1;
ALTER TABLE users ADD COLUMN IF NOT EXISTS frame_level INT NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS signature TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS bag_capacity INT NOT NULL DEFAULT 50;

ALTER TABLE gifts ADD COLUMN IF NOT EXISTS category VARCHAR(24) NOT NULL DEFAULT 'basic';
ALTER TABLE gifts ADD COLUMN IF NOT EXISTS combo_group VARCHAR(40);
ALTER TABLE gifts ADD COLUMN IF NOT EXISTS combo_max INT NOT NULL DEFAULT 1;
ALTER TABLE gifts ADD COLUMN IF NOT EXISTS min_vip INT NOT NULL DEFAULT 0;
ALTER TABLE gifts ADD COLUMN IF NOT EXISTS min_svip INT NOT NULL DEFAULT 0;
ALTER TABLE gifts ADD COLUMN IF NOT EXISTS luck_weight INT NOT NULL DEFAULT 0;
ALTER TABLE gifts ADD COLUMN IF NOT EXISTS lucky_multiplier NUMERIC(8,2) NOT NULL DEFAULT 1;
ALTER TABLE gifts ADD COLUMN IF NOT EXISTS sort_order INT NOT NULL DEFAULT 0;
ALTER TABLE gifts ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}';

CREATE TABLE IF NOT EXISTS user_bag (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  gift_id UUID NOT NULL REFERENCES gifts(id) ON DELETE CASCADE,
  quantity BIGINT NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(user_id,gift_id)
);
CREATE TABLE IF NOT EXISTS cv_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), title VARCHAR(120) NOT NULL,
  description TEXT, banner_url TEXT, starts_at TIMESTAMPTZ, ends_at TIMESTAMPTZ,
  target_type VARCHAR(32) NOT NULL DEFAULT 'gift_value', target_value BIGINT NOT NULL DEFAULT 0,
  reward_coins BIGINT NOT NULL DEFAULT 0, reward_xp BIGINT NOT NULL DEFAULT 0,
  enabled BOOLEAN NOT NULL DEFAULT TRUE, rules JSONB NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS cv_event_progress (
  event_id UUID NOT NULL REFERENCES cv_events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, progress BIGINT NOT NULL DEFAULT 0,
  claimed BOOLEAN NOT NULL DEFAULT FALSE, updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(event_id,user_id)
);
CREATE TABLE IF NOT EXISTS owner_settings (
  key VARCHAR(80) PRIMARY KEY, value JSONB NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_gifts_category_sort ON gifts(category,sort_order,price_coins);
CREATE INDEX IF NOT EXISTS idx_cv_events_enabled ON cv_events(enabled,starts_at,ends_at);

INSERT INTO gifts(name,price_coins,category,combo_group,combo_max,min_vip,sort_order,metadata)
SELECT * FROM (VALUES
 ('وردة ذهبية',20,'basic','flowers',20,0,10,'{"icon":"🌹","animation":"pop"}'::jsonb),
 ('قلب نيون',50,'basic','hearts',50,0,20,'{"icon":"💖","animation":"pulse"}'::jsonb),
 ('تاج ملكي',250,'basic','royal',10,0,30,'{"icon":"👑","animation":"shine"}'::jsonb),
 ('زوم بوم',500,'combo','boom',99,0,40,'{"icon":"💥","animation":"combo"}'::jsonb),
 ('صاروخ كبرياء',1000,'combo','rocket',50,0,50,'{"icon":"🚀","animation":"launch"}'::jsonb),
 ('مطر ذهب',2500,'combo','goldrain',20,2,60,'{"icon":"💰","animation":"rain"}'::jsonb),
 ('صندوق الحظ',800,'luck','lucky',20,0,70,'{"icon":"🎁","animation":"luck","multipliers":[2,3,5,10]}'::jsonb),
 ('عجلة الحظ',3000,'luck','wheel',10,2,80,'{"icon":"🎡","animation":"wheel","multipliers":[2,5,10,20]}'::jsonb),
 ('عرش SVIP',10000,'svip','svip',5,0,90,'{"icon":"💎","animation":"svip"}'::jsonb),
 ('قصر الارتباط',25000,'svip','bond',3,0,100,'{"icon":"💍","animation":"bond"}'::jsonb),
 ('تاج CV',50000,'cv','cv',3,5,110,'{"icon":"🏆","animation":"cv"}'::jsonb)
) AS v(name,price_coins,category,combo_group,combo_max,min_vip,sort_order,metadata)
WHERE NOT EXISTS (SELECT 1 FROM gifts WHERE gifts.name=v.name);

INSERT INTO cv_events(title,description,target_type,target_value,reward_coins,reward_xp,rules)
SELECT 'CV — تاج الحضور','اجمع قيمة هدايا CV خلال مدة الحدث وافتح جوائز المستوى.','gift_value',50000,5000,500,'{"tier":[5000,15000,50000],"type":"cv"}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM cv_events WHERE title='CV — تاج الحضور');

CREATE TABLE IF NOT EXISTS vip_levels (
  id INT PRIMARY KEY,
  kind VARCHAR(8) NOT NULL CHECK (kind IN ('VIP','SVIP')),
  threshold_coins BIGINT NOT NULL DEFAULT 0,
  title VARCHAR(80) NOT NULL,
  benefits JSONB NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS charge_levels (
  id INT PRIMARY KEY,
  threshold_coins BIGINT NOT NULL DEFAULT 0,
  title VARCHAR(80) NOT NULL,
  benefits JSONB NOT NULL DEFAULT '{}'
);
INSERT INTO vip_levels(id,kind,threshold_coins,title,benefits) VALUES
(1,'VIP',10000,'VIP 1','{"frame":true,"entry_effect":true}'),
(2,'VIP',30000,'VIP 2','{"frame":true,"entry_effect":true,"gift_discount":2}'),
(3,'VIP',80000,'VIP 3','{"frame":true,"entry_effect":true,"exclusive_gifts":true}'),
(4,'VIP',150000,'VIP 4','{"frame":true,"entry_effect":true,"exclusive_room_badge":true}'),
(5,'VIP',300000,'VIP 5','{"frame":true,"entry_effect":true,"exclusive_gifts":true,"priority_support":true}')
ON CONFLICT(id) DO NOTHING;
INSERT INTO vip_levels(id,kind,threshold_coins,title,benefits) VALUES
(101,'SVIP',500000,'SVIP 1','{"svip_frame":true,"bond_gifts":true,"exclusive_entry":true}'),
(102,'SVIP',1000000,'SVIP 2','{"svip_frame":true,"bond_gifts":true,"exclusive_entry":true,"special_effect":true}'),
(103,'SVIP',2500000,'SVIP 3','{"svip_frame":true,"bond_gifts":true,"exclusive_entry":true,"cv_access":true}'),
(104,'SVIP',5000000,'SVIP 4','{"svip_frame":true,"bond_gifts":true,"exclusive_entry":true,"cv_access":true,"premium_support":true}'),
(105,'SVIP',10000000,'SVIP 5','{"svip_frame":true,"bond_gifts":true,"exclusive_entry":true,"cv_access":true,"owner_events":true}')
ON CONFLICT(id) DO NOTHING;
INSERT INTO charge_levels(id,threshold_coins,title,benefits) VALUES
(1,0,'شحن 1','{"badge":"bronze"}'),(2,10000,'شحن 2','{"badge":"silver"}'),(3,50000,'شحن 3','{"badge":"gold"}'),(4,150000,'شحن 4','{"badge":"ruby"}'),(5,500000,'شحن 5','{"badge":"diamond"}'),(6,1000000,'شحن 6','{"badge":"royal"}'),(7,2500000,'شحن 7','{"badge":"royal_plus"}'),(8,5000000,'شحن 8','{"badge":"legend"}'),(9,10000000,'شحن 9','{"badge":"legend_plus"}'),(10,25000000,'شحن 10','{"badge":"supreme"}')
ON CONFLICT(id) DO NOTHING;
