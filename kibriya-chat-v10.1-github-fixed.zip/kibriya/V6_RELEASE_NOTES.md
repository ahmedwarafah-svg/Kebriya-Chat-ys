# Kibriya Chat V6 — VIP/SVIP + Games + Starter Balance

## Added
- VIP levels 1..15 with cumulative benefits.
- SVIP levels 1..12 with cumulative benefits.
- Thresholds stored in PostgreSQL and returned by `/api/levels`.
- New accounts receive 1,000,000 Coins as a one-time starter/test balance.
- Five in-app virtual-coin games: Lucky Wheel, Treasure Boxes, Royal Dice, Speed Tap, Pride Guess.
- Daily free-play limits and server-side reward ledger for games.
- Owner dashboard count for enabled games.
- Eight premium gift catalog entries with prepared SVG artwork.
- Gift catalog remains compatible with future Lottie/WebP/MP4 animation URLs.
- No real-money payout or gambling is implemented; game rewards are virtual Coins only.

## Production integrations still external
- Voice provider credentials.
- Domain/HTTPS.
- Payment provider and store billing.
- Optional CDN/object storage for media at scale.
